drop table LIVREUR;
drop table CATEGORIE;
drop table TIMES;
drop table DATES;
drop table CLIMAT;
drop table LOCALISATION;

create table LOCALISATION
(
ID_LOCALISATION INTEGER,
adresse varchar (50),
ville varchar (50),
CONSTRAINT PK_LOCALISATION PRIMARY KEY (ID_LOCALISATION)
);

create table CLIMAT 
( ID_CLIMAT INTEGER,
  description varchar (50),
  temperature varchar (50),
  CONSTRAINT PK_CLIMAT PRIMARY KEY (ID_CLIMAT)
);


create table DATES(
    ID_DATE integer,
    jour varchar2(50),
    mois varchar2(50),
    annee varchar2(50),
    CONSTRAINT PK_DATES PRIMARY KEY (ID_DATE)
);

create table TIMES(
    ID_TIME integer,
    secondes integer,
    minutes integer,
    heures integer,
     CONSTRAINT PK_TIMES PRIMARY KEY(ID_TIME)
); 
create table CATEGORIE(
    id_categorie integer,
    categorie varchar2(50) CHECK(categorie IN('jeune', 'adulte', 'ainee')),
    age_min integer,
    age_max integer,
    CONSTRAINT PK_CATEGORIE PRIMARY KEY (id_categorie)   
);


create table LIVREUR
(
ID_Climat INTEGER,
ID_DATE INTEGER,
ID_Localisation INTEGER,
ID_TIME integer,
nom varchar (50),
age INTEGER,
ID_Categorie INTEGER,
type_Vehicule varchar (50),
CONSTRAINT ID_Climat FOREIGN KEY (ID_CLIMAT)REFERENCES Climat(ID_CLIMAT),
CONSTRAINT ID_DATE FOREIGN KEY (ID_DATE)REFERENCES DATES(ID_DATE),
CONSTRAINT ID_Localisation FOREIGN KEY (ID_Localisation) REFERENCES LOCALISATION(ID_Localisation),
CONSTRAINT ID_TIME FOREIGN KEY (ID_TIME)REFERENCES TIMES(ID_TIME),
CONSTRAINT ID_CATEGORIE FOREIGN KEY (ID_categorie)REFERENCES CATEGORIE(id_categorie)
);
