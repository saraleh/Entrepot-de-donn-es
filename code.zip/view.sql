--------------------------------------------------------------
#NOMBRE DE COMMANDE par categorie de promotion par mois
CREATE MATERIALIZED VIEW CommandePromotion( id_DATE, id_categorie, nbcmd) 
 AS SELECT COUNT(*),FACTURE_CLIENT.id_categorie, FACTURE_CLIENT.id_DATE
 FROM FACTURE_CLIENT
 GROUP BY  FACTURE_CLIENT.id_categorie, FACTURE_CLIENT.id_DATE;

#NOMBRE DE COMMANDE par PASS 
CREATE MATERIALIZED VIEW CommandePass(FACTURE_CLIENT.id_client, nbcmd) 
AS SELECT FACTURE_CLIENT.id_client, COUNT (*)
FROM FACTURE_CLIENT
GROUP BY  CLIENT.pass;

#NOMBRE DE COMMANDE PAR Restaurant Par mois
CREATE MATERIALIZED VIEW CommandeRestau(ID_RESTAURANT, id_date, nbcmd)
AS SELECT FACTURE_CLIENT.ID_RESTAURANT, FACTURE_CLIENT.id_date, COUNT(*)
FROM FACTURE_CLIENT
GROUP BY FACTURE_CLIENT.ID_RESTAURANT, FACTURE_CLIENT.id_date;

#NOMBRE DE COMMANDE PAR Mois
CREATE MATERIALIZED VIEW Commandemois(ID_Date, nbcmd)
AS SELECT FACTURE_CLIENT.ID_Date, COUNT (*)
FROM FACTURE_CLIENT 
GROUP BY  FACTURE_CLIENT.ID_Date;

#nb de cmd par categorie d age
CREATE MATERIALIZED VIEW Commandecategorie(id_categorie, nbcmd)
AS SELECT FACTURE_CLIENT.id_categorie, COUNT (*)
FROM FACTURE_CLIENT
GROUP BY  FACTURE_CLIENT.id_categorie; 

--------------------------------------
#nombre de livreur par climat
CREATE MATERIALIZED VIEW livreurclimat(ID_CLIMAT, nbliv)
AS SELECT LIVREUR.ID_Climat,COUNT(*)
FROM LIVREUR
GROUP BY LIVREUR.ID_Climat;


#nombre de livreur par categorie d'age
CREATE MATERIALIZED VIEW livreurcategorie( id_categorie, nblivreur)
AS SELECT LIVREUR.id_categorie , COUNT(*)
FROM LIVREUR
GROUP BY LIVREUR.id_categorie ;

#nombre de livreur par localistaion
CREATE MATERIALIZED VIEW livreurcategorie( ID_Localisation, nblivreur)
AS SELECT LIVREUR.ID_Localisation , COUNT(*)
FROM LIVREUR
GROUP BY LIVREUR.ID_Localisation;
---------------------------
CREATE MATERIALIZED VIEW LivreurLoc( id_climat, id_categorie, nbcmd) AS
SELECT COUNT(ID_Climat), ID_categorie 
FROM LIVREUR
GROUP BY ID_categorie;

CREATE MATERIALIZED VIEW LivreurLoc AS
SELECT ID_categorie  
FROM LIVREUR

------------------------------------------------------------------------------------

 CREATE VIEW VIEW_DATE
 AS SELECT A.id_date
 FROM DATEE A, DATES B WHERE A.id_DATE= B.id_DATE;

 CREATE VIEW VIEW_CATEGORIE
 AS SELECT c.id_categorie
 FROM CATEGORIE_AGE c, CATEGORIE d WHERE c.ID_categorie = d.ID_categorie;

CREATE VIEW VIEW_TIME
 AS SELECT d.id_time
 FROM TIMEE d, TIMES e WHERE d.id_time= e.id_time;







