drop table FACTURE_CLIENT;
drop table CATEGORIE_AGE;
drop table PROMOTION;
drop table TIMEE;
drop table DATEE;
drop table CLIENT;
drop table RESTAURANT;

create table RESTAURANT
(
    id_restaurant integer,
    nom varchar2(50),
    type varchar2(50),
    adresse varchar2(50),
    ville varchar2(50),
    specialite varchar2(50), 
    note integer,
    CONSTRAINT PK_RESTAURANT PRIMARY KEY (id_restaurant)
);
prompt -- RESTAURANT créé ;

create table CLIENT
(
    id_client integer,
    nom varchar2(50),
    prenom varchar2(50),
    pass integer,
    age varchar2(50), 
    sexe varchar2(50),
    ville varchar2(50),
    adresse varchar2(50),
    CONSTRAINT PK_CLIENT PRIMARY KEY (id_client)
 );
prompt -- CLIENT créé ;

create table DATEE(
    id_date integer,
    jour varchar2(50),
    mois varchar2(50),
    annee varchar2(50),
    CONSTRAINT PK_DATE PRIMARY KEY (id_date)
);
prompt -- DATEE créé ;

create table TIMEE(
    id_time integer,
    heures integer,
    minutes integer,
    secondes integer,
     CONSTRAINT PK_TIMEE PRIMARY KEY(id_time)
);    

create table PROMOTION(
    id_promotion integer,
    montant float(5),
    categorie varchar2(50),
    CONSTRAINT PK_PROMOTION PRIMARY KEY(id_promotion)
);
prompt -- PROMOTION créé ;

create table CATEGORIE_AGE(
    id_categorie integer,
    categorie varchar2(50) CHECK(categorie IN('jeune', 'adulte', 'ainée')),
    age_min integer,
    age_max integer,
    CONSTRAINT PK_CATEGORIE_AGE PRIMARY KEY (id_categorie)   
);
prompt -- CATEGORIE_AGE créé ;


create table FACTURE_CLIENT(
    id_time integer,
    id_date integer,
    id_promotion integer,
    id_restaurant integer,
    id_client integer,
    id_categorie integer,
    CONSTRAINT FK_time FOREIGN KEY(id_time) REFERENCES TIMEE(id_time),
    CONSTRAINT FK_DATEE FOREIGN KEY(id_date) REFERENCES DATEE(id_date),
    CONSTRAINT FK_POMOTION FOREIGN KEY(id_promotion) REFERENCES PROMOTION(id_promotion),
    CONSTRAINT FK_RESTAURANT FOREIGN KEY(id_restaurant) REFERENCES RESTAURANT(id_restaurant),
    CONSTRAINT FK_CLIENT FOREIGN KEY(id_client) REFERENCES CLIENT(id_client),
    CONSTRAINT FK_CATEGORIE FOREIGN KEY(id_categorie) REFERENCES CATEGORIE_AGE (id_categorie),
    prix float(5)
);
prompt -- Facture_CLIENT créé ;






 
